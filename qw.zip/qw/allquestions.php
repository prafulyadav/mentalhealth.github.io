<?php session_start(); ?>
<?php include "connection.php";
if (isset($_SESSION['admin'])) {
?>

<!DOCTYPE html>
<html>
	<head>
		<title>SELFCAREBOOSTER</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css">
		<link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">
		<style>body {
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
}

li{
	list-style: none;
}

a{
	text-decoration: none;
}

label{
	display: inline-block;
	width: 180px;
}

input[type='text']{
	width: 97%;
	padding: 4px;
	border-radius: 5px;
	border:1px #ccc solid;
}

input[type='number']{
	width: 50px;
	padding: 4px;
	border-radius: 5px;
	border:1px #ccc solid;
}

.container{
	width: 60%;
	margin: 0 auto;
	overflow: auto;
}

header{
	border-bottom: 3px #272726 solid;
	background: #3A3A36;
	color: white;
}

a.add {
	display: inline-block;
	color: #666;
	background: #f4f4f4;
	border-left: 7px #272726 solid;
	padding:6px 13px;
	position: right;
}

footer{
	border-top: 3px #272726 solid;
	background: #3A3A36;
	color: #BBBBB9;
	text-align: center;
	padding-top: 5px;
	padding-bottom: 5px;
}

main{
	padding-bottom: 20px;
	background: #61615E;
	color: white;
}


a.start{
	display: inline-block;
	color: #000000;
	background: #99CC00;
	border-left: 7px #272726 solid;
	padding:6px 13px;
}

.current{
	padding:10px;
	background: #8D8D8B;
	border-left: 10px #272726 solid;
	margin: 20px 0 10px 0;
}

@media only screen and (max-width: 960px){
	.container{
		width: 60%;
	}
}
</style>
	</head>

	<body>
		<header>
			<div class="container">
				<!-- <h1>Quiz to check mental health status</h1> -->
				<a href="index.php" class="start">Home</a>
				<a href="add.php" class="start">Add Question</a>
				<a href="allquestions.php" class="start">All Questions</a>
				<a href="players.php" class="start">Players</a>
				<a href="exit.php" class="start">Logout</a>
				
			</div>
		</header>

		
	<h1> All Questions</h1>
	<table class="data-table">
		<caption class="title">All kuiz questions</caption>
		<thead>
			<tr>
				<th>Q.NO</th>
				<th>Question</th>
				<th>Option1</th>
				<th>Option2</th>
				<th>Option3</th>
				<th>Option4</th>
				<th>Correct Answer </th>
				<th>Edit</th>
			</tr>
		</thead>
		<tbody>
        
        <?php 
            
            $query = "SELECT * FROM questions ORDER BY qno DESC";
            $select_questions = mysqli_query($conn, $query) or die(mysqli_error($conn));
            if (mysqli_num_rows($select_questions) > 0 ) {
            while ($row = mysqli_fetch_array($select_questions)) {
                $qno = $row['qno'];
                $question = $row['question'];
                $option1 = $row['ans1'];
                $option2 = $row['ans2'];
                $option3 = $row['ans3'];
                $option4 = $row['ans4'];
                $Answer = $row['correct_answer'];
                echo "<tr>";
                echo "<td>$qno</td>";
                echo "<td>$question</td>";
                echo "<td>$option1</td>";
                echo "<td>$option2</td>";
                echo "<td>$option3</td>";
                echo "<td>$option4</td>";
                echo "<td>$Answer</td>";
                echo "<td> <a href='editquestion.php?qno=$qno'> Edit </a></td>";
              
                echo "</tr>";
             }
         }
        ?>
	
		</tbody>
		
	</table>
</body>
</html>

<?php } 
else {
	header("location: admin.php");
}
?>


