<?php 
session_start();
include "connection.php";
if (isset($_SESSION['id'])) {
$query = "SELECT * FROM questions";
$run = mysqli_query($conn , $query) or die(mysqli_error($conn));
$total = mysqli_num_rows($run);
?>

<html>
	<head>
		<title>SELFCAREBOOSTER</title>
		<link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">
		<style>

body {
	font-family: arial;
	font-size: 15px;
	line-height: 1.6em;
}

li{
	list-style: none;
}

a{
	text-decoration: none;
}

label{
	display: inline-block;
	width: 180px;
}

input[type='text']{
	width: 97%;
	padding: 4px;
	border-radius: 5px;
	border:1px #ccc solid;
}

input[type='number']{
	width: 50px;
	padding: 4px;
	border-radius: 5px;
	border:1px #ccc solid;
}

.container{
	width: 60%;
	margin: 0 auto;
	overflow: auto;
}

header{
	border-bottom: 3px #272726 solid;
	background: #3A3A36;
	color: white;
}

a.add {
	display: inline-block;
	color: #666;
	background: #f4f4f4;
	border-left: 7px #272726 solid;
	padding:6px 13px;
	position: right;
}

footer{
	border-top: 3px #272726 solid;
	background: #3A3A36;
	color: #BBBBB9;
	text-align: center;
	padding-top: 5px;
	padding-bottom: 5px;
}

main{
	padding-bottom: 20px;
	background: #61615E;
	color: white;
}


a.start{
	display: inline-block;
	color: #000000;
	background: #99CC00;
	border-left: 7px #272726 solid;
	padding:6px 13px;
}

.current{
	padding:10px;
	background: #8D8D8B;
	border-left: 10px #272726 solid;
	margin: 20px 0 10px 0;
}

@media only screen and (max-width: 960px){
	.container{
		width: 60%;
	}
}

		</style>
	</head>

	<body>
		<header>
			<div class="container">
				<h1>Quiz to check mental health status</h1>
			</div>
		</header>

		<main>
			<div class="container">
				<h2>Welcome to Quiz to check mental health status !</h2>
				<p>This is just a simple quiz game to test your knowledge!</p>
				<ul>
				    <li><strong>Number of questions: </strong><?php echo $total; ?></li>
				    <li><strong>Type: </strong>Multiple Choice</li>
				    <li><strong>Estimated time for each question: </strong><?php echo $total * 0.05 * 600; ?> seconds</li>
				     <li><strong>Score: </strong>   &nbsp; +1 point for each correct answer</li>
				</ul>
				<a href="question.php?n=1" class="start">Start Quiz</a>
				<a href="exit.php" class="add">Exit</a>

			</div>
		</main>

		<footer>
			<div class="container">
			Quiz to check mental health status
			</div>
		</footer>

	</body>
</html>
<?php unset($_SESSION['score']); ?>
<?php }
else {
	header("location: index.php");
}
?>